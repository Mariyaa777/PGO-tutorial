
public class Goal {
	public int year;
	public int month;
	public int day;
	
	public String name;
	public int bonus;
	
	Goal(int year, int month, int day, String name, int bonus) {
		this.year = year;
		this.month = month;
		this.day = day;
		
		this.name = name;
		this.bonus = bonus;
	}	
}
