
public class Technology {

	public String name;
	public int bonus;
	
	Technology(String name, int bonus){
		this.name = name;
		this.bonus = bonus;
	}
}
